package co.edu.icesi.ci.thymeval.model;

public enum UserType {
	patient,doctor, ADMIN
}
