package co.edu.icesi.ci.thymeval.model;

public interface PersonalInfoValidation {

}
