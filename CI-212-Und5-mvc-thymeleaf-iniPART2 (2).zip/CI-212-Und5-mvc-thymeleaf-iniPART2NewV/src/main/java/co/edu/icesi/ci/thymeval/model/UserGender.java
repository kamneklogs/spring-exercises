package co.edu.icesi.ci.thymeval.model;

public enum UserGender {
	masculine,femenine
}
