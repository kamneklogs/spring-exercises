package co.edu.icesi.ci.thymeval.controller.interfaces;

public interface UserController {

}
